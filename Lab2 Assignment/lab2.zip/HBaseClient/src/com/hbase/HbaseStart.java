package com.hbase;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.RowLock;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.KeyValue;
public class HbaseStart
{
	static public void main(String args[]) throws IOException {
		
		//createTable();
		//insertTable();
        //retrieveTable();
		getAllRow();
		//deleteTable();
		}
	
	
	public static void createTable() throws IOException
	{
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.147");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.147:60010");
		
		HBaseAdmin admin = new HBaseAdmin(config);
		
		try {
			 HBaseConfiguration hc = new HBaseConfiguration(new Configuration());
			
			  HTableDescriptor ht = new HTableDescriptor("pnnqb"); 
			  ht.addFamily( new HColumnDescriptor("humidity"));
			  ht.addFamily( new HColumnDescriptor("temperature"));
			  
			  ht.addFamily( new HColumnDescriptor("latitude"));

			  ht.addFamily( new HColumnDescriptor("longitude"));
			  
			  ht.addFamily( new HColumnDescriptor("Date"));
			  
			  ht.addFamily( new HColumnDescriptor("x"));
			  
			  ht.addFamily( new HColumnDescriptor("y"));
			  
			  ht.addFamily( new HColumnDescriptor("z"));
			
			  
			  System.out.println( "connecting" );

			  HBaseAdmin hba = new HBaseAdmin( hc );

			  System.out.println( "Creating Table" );

			  hba.createTable( ht );

			  System.out.println("Done......");
			  
			  	
        } finally {
            admin.close();
        }
		
		
	}
	
	
	public static void insertTable() throws IOException{
	
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.147");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.147:60010");
         
         
         String latitude="",longitude="",Date="",x="",y="",z="",humidity="",temperature="";
         

		  HTable table = new HTable(config, "pnnqb");
	
		 Put p = new Put(Bytes.toBytes("row1"));
		  int timestamp=10000;
		  int count=1;
         
        BufferedReader br = null;
         
 		try {
  
 			String sCurrentLine;
  
 			br = new BufferedReader(new FileReader("/Users/kowsiknalluri/Desktop/873.txt"));
 				
 			/*while ((sCurrentLine = br.readLine()) != null) {
 				
				 Put p = new Put(Bytes.toBytes("row1"),timestamp);
				
				if(sCurrentLine.equals(""))
				{
					continue;
				}
				System.out.println("\nCurrent Line :" + sCurrentLine);
				String[] array = sCurrentLine.split("\t");
				String delim="#";
				int check=0;
				while(array[check].contains("*")==false)
				{
					System.out.println("\nInside while :" + array[check]+"\t" +check);
					String[] words=array[check].split(delim);
					System.out.println("Inside after split : "+ words[0]+"\t"+words[1]);
					if (words[0].contains("Latitude"))
						latitude = words[1];
					if (words[0].contains("Longitude"))
						longitude=words[1];
					if (words[0].contains("Date"))
						Date=words[1];
					if (words[0].contains("X"))
						x=words[1];
					if (words[0].contains("Y"))
						y=words[1];
					if (words[0].contains("Z"))
						z=words[1];
					if (words[0].contains("Humidity"))
						humidity = words[1];
					if (words[0].contains("Humidity Ambient temperature"))
						temperature=words[1];
					check++;
					System.out.println("Date : "+Date);
					System.out.println("Latitude : "+latitude);
					System.out.println("Longitude : "+longitude);
					System.out.println("Humidity : "+humidity);
					System.out.println("Temperature : "+temperature);
					
				//	System.out.println("Date : "+x);
				
				}
				
				if (latitude!="" || longitude!="")
				{
					p.add(Bytes.toBytes("Location"), Bytes.toBytes("col"+count),Bytes.toBytes(latitude));
					p.add(Bytes.toBytes("Location"), Bytes.toBytes("col"+(count+1)),Bytes.toBytes(longitude));
					System.out.println(" Inside if condition Latitude : "+latitude);
				} 
				// p.add(Bytes.toBytes("longitude"), Bytes.toBytes("col"+(count+1)),Bytes.toBytes(longitude));
				if (Date!="")
				 p.add(Bytes.toBytes("Date"), Bytes.toBytes("col"+(count+2)),Bytes.toBytes(Date));
				//if (x!="" || y!="" || z!="")
				 p.add(Bytes.toBytes("Dimensions"), Bytes.toBytes("col"+(count+3)),Bytes.toBytes(x));
				p.add(Bytes.toBytes("Dimensions"), Bytes.toBytes("col"+(count+4)),Bytes.toBytes(y));
				p.add(Bytes.toBytes("Dimensions"), Bytes.toBytes("col"+(count+5)),Bytes.toBytes(z));
				 if (humidity !="")
					 p.add(Bytes.toBytes("Humidity"), Bytes.toBytes("col"+(count+6)),Bytes.toBytes(humidity));
				 if (temperature!="")
					 p.add(Bytes.toBytes("Temperature"), Bytes.toBytes("col"+(count+7)),Bytes.toBytes(temperature));
			//	p.add(Bytes.toBytes("y"), Bytes.toBytes("col"+(count+4)),Bytes.toBytes(y));
				
			//	p.add(Bytes.toBytes("z"), Bytes.toBytes("col"+(count+5)),Bytes.toBytes(z));
				 
			      table.put(p);
			     // check++;
			      count=count+8;
			      timestamp=timestamp+1;
				
			}		
 			*/
 			
 			
  
 			while ((sCurrentLine = br.readLine()) != null) {
 				
 				if(sCurrentLine.equals(""))
 				{
 					continue;
 				}
 				
 				String[] array = sCurrentLine.split("\t");
 				humidity = array[0];
 				temperature=array[1];
 				latitude = array[2];
 				longitude=array[3];
 				Date=array[4];
 				x=array[5];
 				y=array[6];
 				z=array[7];
 				
 				p.add(Bytes.toBytes("humidity"), Bytes.toBytes("col"+count),Bytes.toBytes(humidity));
				  
				 p.add(Bytes.toBytes("temperature"), Bytes.toBytes("col"+(count+1)),Bytes.toBytes(temperature));
 				  p.add(Bytes.toBytes("latitude"), Bytes.toBytes("col"+count+2),Bytes.toBytes(latitude));
 				  
 				 p.add(Bytes.toBytes("longitude"), Bytes.toBytes("col"+(count+3)),Bytes.toBytes(longitude));
 				 
 				 p.add(Bytes.toBytes("Date"), Bytes.toBytes("col"+(count+4)),Bytes.toBytes(Date));
 				 
 				 p.add(Bytes.toBytes("x"), Bytes.toBytes("col"+(count+5)),Bytes.toBytes(x));
 				 
 				p.add(Bytes.toBytes("y"), Bytes.toBytes("col"+(count+6)),Bytes.toBytes(y));
 				
 				p.add(Bytes.toBytes("z"), Bytes.toBytes("col"+(count+7)),Bytes.toBytes(z));

 			      table.put(p);
 			      System.out.println("added");
 			      
 			      count=count+1;
 				
 			}
  
 		} catch (IOException e) {
 			e.printStackTrace();
 		} finally {
 			try {
 				if (br != null)br.close();
 			} catch (IOException ex) {
 				ex.printStackTrace();
 			}
 		}
         
         
		
		
	  
	    
	}
	
	
	public static void retrieveTable() throws IOException{
		
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.147");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.147:60010");
		
		
		  HTable table = new HTable(config, "pnnqb");
		
		 Get g = new Get(Bytes.toBytes("row1"));

		  Result r = table.get(g);
		  byte [] value = r.getValue(Bytes.toBytes("humidity"),Bytes.toBytes("col1"));
		  byte [] value1 = r.getValue(Bytes.toBytes("temperature"),Bytes.toBytes("col2"));

		  byte [] value2 = r.getValue(Bytes.toBytes("latitude"),Bytes.toBytes("col3"));

		  byte [] value3 = r.getValue(Bytes.toBytes("longitude"),Bytes.toBytes("col4"));

		  byte [] value4 = r.getValue(Bytes.toBytes("Date"),Bytes.toBytes("col5"));
		  
		  byte [] value5 = r.getValue(Bytes.toBytes("x"),Bytes.toBytes("col6"));
		  
		  byte [] value6 = r.getValue(Bytes.toBytes("y"),Bytes.toBytes("col7"));
		  
		  byte [] value7 = r.getValue(Bytes.toBytes("z"),Bytes.toBytes("col8"));
		  
		  
		  String valueStr = Bytes.toString(value);

		  String valueStr1 = Bytes.toString(value1);
		  
		  String valueStr2 = Bytes.toString(value2);
		  
		  String valueStr3 = Bytes.toString(value3);
		  
		  String valueStr4 = Bytes.toString(value4);
		  
		  String valueStr5 = Bytes.toString(value5);
		  String valueStr6 = Bytes.toString(value6);
		  String valueStr7 = Bytes.toString(value7);
		 
		  
		  System.out.println("GET: " +"humidity: "+ valueStr);
		  System.out.println("GET: " +"temperature: "+ valueStr1);
		  System.out.println("GET: " +"latitude: "+ valueStr2+"longitude: "+valueStr3);
		  System.out.println("GET: " +"Date: "+ valueStr4);
		  System.out.println("GET: " +"x: "+ valueStr5);
		  System.out.println("GET: " +"y: "+ valueStr6);
		  System.out.println("GET: " +"z: "+ valueStr7);

		  

		  Scan s = new Scan();

		  s.addColumn(Bytes.toBytes("latitude"), Bytes.toBytes("col3"));

		  s.addColumn(Bytes.toBytes("longitude"), Bytes.toBytes("col4"));

		  ResultScanner scanner = table.getScanner(s);

		  try
		  {
		   for (Result rr = scanner.next(); rr != null; rr = scanner.next())
		   {
		    System.out.println("Found row : " + rr);
		   }
		  } finally
		  {
		   // Make sure you close your scanners when you are done!
		   scanner.close();
		  }
		
	}

	public static void getAllRow() throws IOException
	{
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.147");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.147:60010");
         
         HTable table = new HTable(config, "pnnqb");
         Get g = new Get(Bytes.toBytes("row1"));

		  Result r = table.get(g);
         for(KeyValue kv : r.raw()){
             System.out.print(new String(kv.getRow()) + " " );
             System.out.print(new String(kv.getFamily()) + ":" );
             System.out.print(new String(kv.getQualifier()) + " " );
             System.out.print(kv.getTimestamp() + " " );
             System.out.println(new String(kv.getValue()));
         }
         
   /*      for(KeyValue kv : r.raw()){
        	 
        	 String familyname = new String(kv.getFamily());
            
        	 if(familyname.equals("Accelerometer"))
        	 {
        		 System.out.println("=============="+familyname+"==============");
        		 System.out.print(new String(kv.getQualifier())+":");
        		 System.out.println(new String(kv.getValue()));
        	 }
        	 
         }*/
	}
	
	
	
	public static void deleteTable() throws IOException{
		
		Configuration config = HBaseConfiguration.create();		 
		config.clear();
         config.set("hbase.zookeeper.quorum", "134.193.136.147");
         config.set("hbase.zookeeper.property.clientPort","2181");
         config.set("hbase.master", "134.193.136.147:60010");
         
         HBaseAdmin admin = new HBaseAdmin(config);
         admin.disableTable("pnnqb");
         admin.deleteTable("pnnqb");

	}
}

